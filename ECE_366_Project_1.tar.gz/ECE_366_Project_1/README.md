# ECE_366_Project_1
 All files for the ECE 366 Project 1

 Meet out group members:

 - Nathan Sopt
 - Declan Hurless
 - Jesus Garcia
 - Ephren Manning

 In this project you will find all of our code for VERILOG programming of computerized architechture!

 More things to come later. Thanks!
